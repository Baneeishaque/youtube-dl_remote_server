-- MySQL dump 10.13  Distrib 5.6.33-79.0, for Linux (x86_64)
--
-- Host: localhost    Database: vfmobo6d_youtube-dl_remote
-- ------------------------------------------------------
-- Server version	5.6.33-79.0-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration` (
  `system_status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` (`system_status`) VALUES (1);
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hosts`
--

DROP TABLE IF EXISTS `hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `nick` varchar(50) NOT NULL,
  `insertion_date_time` datetime NOT NULL,
  `modification_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hosts`
--

LOCK TABLES `hosts` WRITE;
/*!40000 ALTER TABLE `hosts` DISABLE KEYS */;
INSERT INTO `hosts` (`id`, `name`, `status`, `nick`, `insertion_date_time`, `modification_date_time`) VALUES (5,'PRISM2J-PC',1,'PRISM2J-PC','2018-04-27 16:59:51','2018-05-15 11:07:42'),(6,'PRISM1-PC',1,'PRISM1-PC','2018-04-30 15:41:31','2018-08-13 13:30:16'),(7,'DK-PC',1,'DK-PC','2018-05-10 11:20:41','2018-05-10 13:39:20'),(8,'DESKTOP-U9CPDV4',1,'DESKTOP-U9CPDV4','2018-06-05 10:17:02','2018-07-03 12:51:23'),(9,'PRISM2-PC',1,'PRISM2-PC','2018-06-12 18:38:26','2018-08-06 15:11:05'),(10,'SRF-PC',1,'SRF-PC','2018-06-19 18:40:43','2018-08-14 21:22:38');
/*!40000 ALTER TABLE `hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(250) NOT NULL,
  `host_id` int(11) NOT NULL DEFAULT '9',
  `status` tinyint(4) NOT NULL,
  `insertion_date_time` datetime NOT NULL,
  `modification_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` (`id`, `url`, `host_id`, `status`, `insertion_date_time`, `modification_date_time`) VALUES (6,'https://www.youtube.com/user/GoogleDevelopers/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:45'),(2,'https://www.youtube.com/user/Firebase/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:45'),(5,'https://www.youtube.com/user/GoogleDevelopers/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:45'),(4,'https://www.youtube.com/user/Firebase/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:45'),(7,'https://www.youtube.com/watch?v=6NyZaiwGl1s',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:45'),(8,'https://www.youtube.com/user/googleanalytics/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:45'),(9,'https://www.youtube.com/user/googleanalytics/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:46'),(10,'https://www.youtube.com/user/xdadevelopers/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:46'),(11,'https://www.youtube.com/user/xdadevelopers/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:46'),(12,'https://www.youtube.com/user/1and1/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:46'),(13,'https://www.youtube.com/user/1and1/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:46'),(14,'https://www.youtube.com/user/androiddevelopers/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:46'),(15,'https://www.youtube.com/user/androiddevelopers/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:46'),(16,'https://www.youtube.com/user/BigNerdRanchVideo/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:47'),(17,'https://www.youtube.com/user/BigNerdRanchVideo/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:47'),(18,'https://www.youtube.com/user/CrazyDomains/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:47'),(19,'https://www.youtube.com/user/CrazyDomains/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:47'),(20,'https://www.youtube.com/channel/UCS4dsIMOKXAfPlgCTt4QOvQ/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:47'),(21,'https://www.youtube.com/channel/UCS4dsIMOKXAfPlgCTt4QOvQ/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:47'),(22,'https://www.youtube.com/user/GDGWashingtonDC/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:47'),(23,'https://www.youtube.com/user/GDGWashingtonDC/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:48'),(24,'https://www.youtube.com/channel/UCuWNZL2bWmF-KdHjW07DQmA/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:48'),(25,'https://www.youtube.com/user/szLynAs/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:48'),(26,'https://www.youtube.com/user/szLynAs/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:48'),(27,'https://www.youtube.com/user/namedotcom/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:48'),(28,'https://www.youtube.com/user/namedotcom/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:49'),(29,'https://www.youtube.com/channel/UCbwXnUipZsLfUckBPsC7Jog/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:49'),(30,'https://www.youtube.com/channel/UCbwXnUipZsLfUckBPsC7Jog/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:49'),(31,'https://www.youtube.com/user/gosuddr93/videos',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:49'),(32,'https://www.youtube.com/user/gosuddr93/playlists',6,1,'0000-00-00 00:00:00','2018-07-14 12:29:49');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'vfmobo6d_youtube-dl_remote'
--

--
-- Dumping routines for database 'vfmobo6d_youtube-dl_remote'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-15  2:57:55
